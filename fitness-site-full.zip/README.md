# FitKnow · 健身知识网站

这是一个纯静态的健身知识库网站，包含不同分类的健身视频链接。

## 在线访问
如果你已经启用了 GitHub Pages，可以在这里访问：
[https://你的用户名.github.io/fitness-site/](https://你的用户名.github.io/fitness-site/)

## 使用说明
- 修改 `index.html` 文件里的 `SITE_DATA` 部分即可更换分类、视频和站点标题。
- 支持搜索、按难度/平台筛选、常用标签过滤。
- 静态页面，无需后端，直接部署即可。
